import React from 'react'

const StockFile = () => {
  return (
    <>
     <div>
      <h2>StockFile</h2>
      </div>
    </>
   
  )
}

export default StockFile
