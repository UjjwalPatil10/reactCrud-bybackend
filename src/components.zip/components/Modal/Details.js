import React from 'react'

const Details = () => {
  return (
    <>
     <div>
<h2>Details</h2>
      
</div>
    </>
   
  )
}

export default Details
